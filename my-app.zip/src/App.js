import {
  layer, control, //name spaces
  Interactions, Overlays, Controls,     //group
  Map, Layers, Overlay, Util    //objects
} from "react-openlayers";

import './Map.css';

function App() {
  return (
    <div className="App">



      <Map view={{center: [70, 20], zoom: 5}} >
      <Layers>
        <layer.Tile>
        </layer.Tile>
      </Layers>

      <Controls attribution={false} zoom={true}>
        <control.Rotate />
        <control.ScaleLine />
        <control.FullScreen />
        <control.OverviewMap />
        <control.ZoomSlider />
        <control.ZoomToExtent />
        <control.Zoom />
      </Controls>

    </Map>



    </div>
  );
}

export default App;
