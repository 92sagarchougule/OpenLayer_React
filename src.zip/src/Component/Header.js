import React from 'react';

import './Header.css';

const Header = () => (
	<div id="header-grid">
		<div id="logo-grid">
			
		</div>
		<div id="title-grid">
			<h1 id="title">MahaAgriTech Project</h1>
		</div>
		{/*<div id="site-search-grid">
			<Input.Search
				id="site-search-input"
				style={{height: '100%', borderBottom: '1.5px solid'}}
				placeholder="Search Site / Get Help"
			/>
		</div>
		<div id="login-button-grid">
			<div id="login-button-text">
				Login
			</div>
		</div>*/}
	</div>
);

export default Header;