import {
  layer, control, //name spaces
    Controls,     //group
  Map, Layers   //objects
} from "react-openlayers";
import Header from "./Component/Header";
import Footer from "./Component/Footer";

import './Map.css';

function App() {
  return (
    <div className="App">

      
    <Header/>


      <Map view={{center: [70, 20], zoom: 5}} >
      <Layers>
        <layer.Tile>
        </layer.Tile>
      </Layers>

      <Controls attribution={false} zoom={true}>
        <control.Rotate />
        <control.ScaleLine />
        <control.FullScreen />
        <control.OverviewMap />
        <control.ZoomSlider />
        <control.ZoomToExtent />
        <control.Zoom />
      </Controls>

    </Map>

    <Footer/>
    
    
    



    </div>
  );
}

export default App;
